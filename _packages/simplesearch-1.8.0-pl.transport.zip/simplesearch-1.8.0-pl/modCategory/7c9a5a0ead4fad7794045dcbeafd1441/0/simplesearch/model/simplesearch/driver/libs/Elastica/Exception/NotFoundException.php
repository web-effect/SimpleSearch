<?php

namespace Elastica\Exception;

/**
 * Not found exception
 *
 * @category Xodoa
 * @package Elastica
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
class NotFoundException extends \RuntimeException implements ExceptionInterface
{
}
